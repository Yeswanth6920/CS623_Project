/**
 * 
 */
/**
 * @author gowta
 *
 */
module CS623 {
	requires java.sql;
}